Time Lock app allows an Aragon organization to require users to lock tokens by sending them to the Time Lock app for a configurable period of time in order to forward an intent. For example the organization may require users to lock 100 tokens for 1 month before creating a new vote. The user would be able to come back in a month and claim their locked tokens.

Time Lock completed an audit from Consensys Diligence on December, 2019. Outlined [here.](https://diligence.consensys.net/audits/2019/12/dandelion-organizations/)
