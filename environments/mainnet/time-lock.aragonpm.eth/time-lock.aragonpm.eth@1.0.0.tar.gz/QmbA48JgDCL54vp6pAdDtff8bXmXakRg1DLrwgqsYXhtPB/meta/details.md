Time Lock app allows an Aragon organization to require users to lock tokens by sending them to the Time Lock app for a configurable period of time in order to forward an intent. For example the organization may require users to lock 100 tokens for 1 month before creating a new vote. The user would be able to come back in a month and claim their locked tokens.

**WARNING**

The code in this repo has not been audited.
