An Aragon application that aggregates voting power from many distinct sources.

**Features**
- Add multiple distinct sources to represent voting power
- Currently supports ERC20 token and ERC900 staking contracts as sources
