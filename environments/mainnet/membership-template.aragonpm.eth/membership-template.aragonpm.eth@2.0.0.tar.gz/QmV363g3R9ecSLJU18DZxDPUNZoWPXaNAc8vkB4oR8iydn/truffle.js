module.exports = require('@aragon/templates-shared/truffle.js')
