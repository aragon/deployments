An Aragon application that allows any ERC20 token to be converted to and from a non-transferable, checkpointed governance token.

**Features**
- Deposit ERC20 tokens to mint governance tokens.
- Burn governance tokens to withdraw ERC20 tokens.
