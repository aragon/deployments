Token Request app allows users to create a vote which requests an Organization's tokens in exchange for payment. For example a user may request minting 100 organization tokens in exchange for 100 DAI. The request would require a vote to approve, if the vote is rejected the user would receive their payment back and if it is approved the payment would be deposited in the organization's vault.

Token Request completed an audit from Consensys Diligence on December, 2019. Outlined [here.](https://diligence.consensys.net/audits/2019/12/dandelion-organizations/)

