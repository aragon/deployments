The delay app enables Aragon organizations to require a configurable delay between when an intent is sent and when it is executed.

The Delay app completed an audit from Consensys Diligence on December, 2019. Outlined [here.](https://diligence.consensys.net/audits/2019/12/dandelion-organizations/)

