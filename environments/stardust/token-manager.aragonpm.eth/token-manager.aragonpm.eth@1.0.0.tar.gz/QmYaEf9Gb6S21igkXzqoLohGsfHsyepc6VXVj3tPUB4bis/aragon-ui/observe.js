'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var observe = require('./observe-e9f33990.js');
require('./extends-023d783e.js');
require('./_commonjsHelpers-1b94f6bc.js');
require('./getPrototypeOf-55c9e80c.js');
require('./defineProperty-3cad0327.js');
require('react');
require('./getDisplayName-7f913e84.js');
require('./environment.js');
require('./miscellaneous.js');



exports.observe = observe.observe;
//# sourceMappingURL=observe.js.map
