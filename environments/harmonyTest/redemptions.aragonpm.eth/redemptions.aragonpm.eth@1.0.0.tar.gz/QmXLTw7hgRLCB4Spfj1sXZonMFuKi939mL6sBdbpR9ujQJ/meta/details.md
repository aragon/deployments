The Redemptions app allows Aragon organizations to grant their token holders the right to redeem tokens in exchange for a proportional share of the organizations treasury assets.

Redemptions completed an audit from Consensys Diligence on December, 2019. Outlined [here.](https://diligence.consensys.net/audits/2019/12/dandelion-organizations/)

