'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var INPUT_BORDER = 1;
var START_DATE = 'Start day';
var END_DATE = 'End day';

exports.END_DATE = END_DATE;
exports.INPUT_BORDER = INPUT_BORDER;
exports.START_DATE = START_DATE;
//# sourceMappingURL=consts.js.map
