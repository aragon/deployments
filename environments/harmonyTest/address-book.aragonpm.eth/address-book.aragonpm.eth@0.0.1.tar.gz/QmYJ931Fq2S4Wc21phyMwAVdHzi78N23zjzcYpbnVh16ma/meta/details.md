The Address Book app makes it easy to assign human-readable names to Ethereum addresses, an important feature to help recognize the members within an organization.

## Features
- Add, edit and remove new entities to your address book.
- Label your address book entities as individuals or organizations.
