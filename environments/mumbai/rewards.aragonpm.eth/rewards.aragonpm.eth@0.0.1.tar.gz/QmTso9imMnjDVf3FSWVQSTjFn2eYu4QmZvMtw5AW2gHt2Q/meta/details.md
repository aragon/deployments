The Rewards app is used to compensate token holders with dividends, which can either occur on a one-time or recurring basis.

## Features
- Create one-time or recurring dividends that reward members of your organization based on holding a certain asset at specific disbursement dates.
- Create one-time merits that reward members of your organization based on accruing a certain non-transferable asset over a specific period of time.
