'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var observe = require('./observe-ad4a407f.js');
require('./extends-5150c1f4.js');
require('./_commonjsHelpers-1b94f6bc.js');
require('./getPrototypeOf-e2e819f3.js');
require('./defineProperty-fdbd3c46.js');
require('react');
require('./getDisplayName-7f913e84.js');
require('./environment.js');
require('./miscellaneous.js');



exports.observe = observe.observe;
//# sourceMappingURL=observe.js.map
