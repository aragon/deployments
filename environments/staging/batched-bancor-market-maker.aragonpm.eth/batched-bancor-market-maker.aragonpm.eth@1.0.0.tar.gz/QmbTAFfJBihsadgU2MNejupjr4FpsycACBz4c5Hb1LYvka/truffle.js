const truffle = require('@aragon/os/truffle-config')
truffle.solc.optimizer.runs = 1500
module.exports = truffle
