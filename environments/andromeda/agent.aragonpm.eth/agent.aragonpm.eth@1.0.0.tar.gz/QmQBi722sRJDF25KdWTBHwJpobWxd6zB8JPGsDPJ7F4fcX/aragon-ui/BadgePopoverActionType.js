'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var index = require('./index-37353731.js');
require('./_commonjsHelpers-1b94f6bc.js');

var BadgePopoverActionType = index.propTypes.shape({
  label: index.propTypes.node.isRequired,
  onClick: index.propTypes.func.isRequired
});

exports.default = BadgePopoverActionType;
//# sourceMappingURL=BadgePopoverActionType.js.map
