const deployDAOFactory = require('@aragon/os/scripts/deploy-daofactory.js')
const BareKit = artifacts.require('BareKit')

const ensAddr = process.env.ENS

module.exports = async (callback) => {
  if (!ensAddr) {
    callback(new Error("ENS address not found in environment variable ENS"))
  }

  // const { daoFactory } = await deployDAOFactory(null, { artifacts, verbose: false })

  const bareKit = await BareKit.new("0x3f2aa9dd22e97070518ba7988fe9b8724129d497", ensAddr)
  console.log(bareKit.address)

  callback()
}
