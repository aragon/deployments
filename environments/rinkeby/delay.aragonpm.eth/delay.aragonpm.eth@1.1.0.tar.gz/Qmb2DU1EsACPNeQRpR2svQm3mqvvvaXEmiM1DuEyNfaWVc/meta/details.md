The delay app enables Aragon organizations to require a configurable delay between when an intent is sent and when it is executed.

**WARNING**

The code in this repo has not been audited.
