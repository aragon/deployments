'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var KEY_ESC = 27;
var KEY_UP = 38;
var KEY_DOWN = 40;
var KEY_ENTER = 13;

exports.KEY_DOWN = KEY_DOWN;
exports.KEY_ENTER = KEY_ENTER;
exports.KEY_ESC = KEY_ESC;
exports.KEY_UP = KEY_UP;
//# sourceMappingURL=keycodes.js.map
