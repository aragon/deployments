const truffle = require('@aragon/os/truffle-config')
truffle.solc.optimizer.runs = 800
module.exports = truffle
