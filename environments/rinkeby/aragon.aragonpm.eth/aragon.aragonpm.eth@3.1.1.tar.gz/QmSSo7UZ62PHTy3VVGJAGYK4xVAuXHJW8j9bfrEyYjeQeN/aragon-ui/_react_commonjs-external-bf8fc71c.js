'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);



exports.React = React__default;
//# sourceMappingURL=_react_commonjs-external-bf8fc71c.js.map
