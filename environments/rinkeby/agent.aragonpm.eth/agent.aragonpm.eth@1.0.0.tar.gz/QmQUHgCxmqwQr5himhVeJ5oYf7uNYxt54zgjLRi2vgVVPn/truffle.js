module.exports = require("@aragon/os/truffle-config")
